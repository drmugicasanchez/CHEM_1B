# CHEM 1B Section 4.6: Nuclear Chemistry

This folder is ready to upload to a GitHub repository for GitHub Pages.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` and the `assets` folder to the repository's top level.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and the `/ (root)` folder, then click **Save**.
6. GitHub will provide the published site link after deployment finishes.
